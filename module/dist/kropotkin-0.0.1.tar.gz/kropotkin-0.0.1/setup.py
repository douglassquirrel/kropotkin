from distutils.core import setup
setup(name='kropotkin',
      version='0.0.1',
      py_modules=['kropotkin'])
